#include "I-type.h"

I_type::I_type()
{
}

I_type::I_type(vector<string> a)
{
    v=a;
}

// deals with lw and sw type instruction
void I_type::memoryAccess()
{

    if (v.size()<3){
        errorMessage+="ERROR: Not enough data fields. ";
        return;
    }
    else if (v.size()>3){
        errorMessage+="ERROR: Too much data fields. ";
        return;
    }

    if (m.find(v[1])== m.end()){
        errorMessage="ERROR: Register number "+v[1]+" is not valid";
        return;
    }

    if (v[0]=="lw"){
        translated=ConverttoBinary(3,3);
    }
    else {
        translated=ConverttoBinary(4,3);
    }

    if (ConverttoInt(v[2])>3){
        errorMessage="ERROR: Offset value can not be more than 7";
        return;
    }
    if (ConverttoInt(v[2])<0){
        errorMessage="ERROR: Offset value can not be negative";
    }

    translated+=" "+m[v[1]]+" "+ConverttoBinary(toInt(v[2]),3);


}

// deals with addi type instruction
void I_type::decision()
{

    if(v[0]=="addi")
    {
        if (v.size()<3){
            errorMessage+="ERROR: Not enough data fields. ";
            return;
        }
        else if (v.size()>3){
            errorMessage+="ERROR: Too much data fields. ";
            return;
        }


            if (ConverttoInt(v[2])>3){
                errorMessage="ERROR: constant value can not be more than 7";
                return;
            }

            if (ConverttoInt(v[2])<0){
                errorMessage="ERROR: constant value can not be less than 0";
                return;
            }

        if (m.find(v[1])==m.end()){
            errorMessage="ERROR: Register number "+v[1]+" is not valid";
            return;
        }

    }

    else if(v[0]=="addi")
    {
         translated+=ConverttoBinary(2,3)+" "+m[v[1]]+" "+ConverttoBinary(ConverttoInt(v[2]),3);
    }
    else{
        translated=ConverttoBinary(6,3);
        translated+=" "+ConverttoBinary(ConverttoInt(v[1]),5);
    }
}


void I_type::solve(){

    if (v[0]=="lw" || v[0]=="sw"){
        return memoryAccess();
    }
    else if (v[0]=="addi"){
        return decision();
    }
