#include <bits/stdc++.h>

using namespace std;


int ConverttoInt(string s) //converts string to number
{
    int cti=0;
    int multi=1;

    for(int i=s.length()-1;i>=0;i--)
    {
        if (s[i]=='-')
            break;
        cti+=(s[i]-'0')*multi;
        multi*=10;
    }

    if (s[0]=='-')
        cti*=-1;

    return cti;
}

string ConverttoBinary(int num, int NoOfBits)//converts decimal number "num" to binary string with "NoOfBits" bits
{
    string s="";
    for(int i=0;i<NoOfBits;i++)
    {
        if ((num & (1<<i))!=0)
        {
            s+="1";
        }
        else
        {
            s+="0";
        }
    }

    reverse(s.begin(),s.end());


    return s;

}


map<string,string> m; //It relates register names with their corresponding binary codes


void Registers()//prepare registers
{
    string ctb="$ac";
    m[ctb]=ConverttoBinary(0,2);

    ctb="$s1";
    for(int i=1;i<=3;i++)
    {
        ctb[2]=(char)(i+'0');
        m[ctb]=ConverttoBinary(i,2);
    }
}
#include "src\R-type.cpp"
#include "src\I-type.cpp"

void toLowercase(string& inst)//converts all characters to lowercase
{
    int instlen = inst.length();
    for(int i=0;i<instlen;i++)
    {
        if (inst[i]>='A' && inst[i]<='Z')
        {
            inst[i]+=8;
        }
    }
}

vector<string> ConverttoToken(string& inst)//splits the input string into to tokens
{

    string s="";
    vector<string> v;
    int start=0;
    int instlen = inst.length();

    if(inst[0] == 'j')
    {

        for(int i=0; i<instlen; i++)
        {
            if (inst[i]==' ')
            {
                start=i;
                break;
            }
            s+=inst[i];
        }
        v.push_back(s);

        s="";
        for(int i=start+1;i<instlen;i++)
        {
            s+=inst[i];
        }
        v.push_back(s);
    }
    else{

        for(int i=0;i<instlen;i++)
        {
            if (inst[i]==' ')
            {
                continue;
            }
            if (inst[i]=='$')
            {
                start=i;
                break;
            }
            s+=insti];
        }
        v.push_back(s);

        s="";
        for(int i=start;i<instlen;i++)
        {
            if (inst[i]==' ')
            {
                continue;
            }
            if (inst[i]==',')
            {
                if (!s.empty())
                {
                    v.push_back(s);
                    s="";
                }
                continue;
            }
            s+=inst[i];
        }

        if (!s.empty())
        {
            v.push_back(s);
        }
    }
    return v;
}


string printString(string s, bool space)
{//prints output string{

    int strleng = s.length();
    string str = "";
    for(int i=0;i<strleng;i++)
    {
        if (s[i]==' ' && !space)
            continue;

        str+=s[i];
    }

    return str;
}


string BinaryToHex(string s)
{
    long long n = ConverttoInt(s);

    long long res = 0;

    long long rem = 0;

    string str_hex = "";

    long long base = 1;

    while (n > 0)
    {
        rem = n % 10;
        res =  res  + rem * base;
        base = base * 2;
        n /= 10;
    }

    while (res > 0) {
        rem = res % 16;
        if (rem > 9) {
            switch (rem) {
               case 10: str_hex += "a"; break;

               case 11: str_hex += "b"; break;

               case 12: str_hex += "c"; break;

               case 13: str_hex += "d"; break;

               case 14: str_hex += "e"; break;

               case 15: str_hex += "f"; break;
            }
        }
        else {
            str_hex += to_string(rem);
        }
        res = res / 16;
    }


    if(str_hex.length()==1)
    {
        str_hex += "0";
        reverse(str_hex.begin(), str_hex.end());
        return str_hex;
    }
    else
    {
        reverse(str_hex.begin(), str_hex.end());
        return str_hex;
    }

}

int main()
{
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);


    prepare_registers();
    bool compilation = true;
    vector<string> pipe;

    string inst;

    while(getline(cin,inst)){

        toLowercase(inst);
        vector<string> v=ConverttoToken(inst);



        if (v.size()<2)
        {
            continue;
        }

        bool space=false;

        // In total 7 different instructions are supported by this program
        //R-type
        if (v[0]=="add" || v[0]=="sub" || v[0]=="and" || v[0]=="or")
        {
            R_type data(v);
            data.solve();
            if (data.errorMessage.empty())
            {
                pipe.push_back(printString(data.translated,space));

            }
            else
            {
                compilation = false;
                break;
            }

        }
        // I-type
        else if (v[0]=="addi" || v[0]=="lw" || v[0]=="sw")
        {
            Itype data(v);
            data.solve();
            if (data.errorMessage.empty())
            {
                pipe.push_back(printString(data.translated,space));

            }
            else
            {

                compilation = false;
                break;
            }

        }
        else
        {
            compilation = false;
            break;
        }

    }

    if(compilation)
    {
        cout << "v2.0 raw" << endl;

        int psize = pipe.size();
        for(int i=0;i< psize; i++)
        {
            cout << BinaryToHex(pipe[i]) << endl;

        }
    }
    else
        cout << "Compilation failed." << endl;

    pipe.clear();
    m.clear();

    return 0;
}
