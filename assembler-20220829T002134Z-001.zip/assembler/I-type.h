#include <bits/stdc++.h>

using namespace std;

class I_type
{
private:
    void memoryAccess();
    void decision();
public:
    string errorMessage="";
    string translated="";
    vector<string> v;
    I_type();
    I_type(vector<string> a);
    void solve();


};
