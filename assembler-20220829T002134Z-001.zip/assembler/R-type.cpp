#include "R-type.h"

R_type::R_type(){
}

R_type::R_type(vector<string> a){
    v=a;
}

void R_type::solve(){

    if (v.size()<3)
    {
        errorMessage+="ERROR: Not enough data fields. ";
        return;
    }
    else if (v.size()>3)
    {
        errorMessage+="ERROR: Too much data fields. ";
        return;
    }

    int vecsize = v.size();

    if (v[0]=="add"){
        for(int i=1;i<vecsize;i++){
           if (m.find(v[i])==m.end()){
                errorMessage+="ERROR: Register number "+v[i]+" is not valid";
                return;
           }
        }
        translated+=ConverttoBinary(0,3)+" "+m[v[1]]+" "+m[v[2]]+" "+ConverttoBinary(0,1);
    }
    else if (v[0]=="sub"){
        for(int i=1;i<vecsize;i++){
           if (m.find(v[i])==m.end()){
                errorMessage+="ERROR: Register number "+v[i]+" is not valid";
                return;
           }
        }
        translated+=ConverttoBinary(1,3)+" "+m[v[1]]+" "+m[v[2]]+" "+ConverttoBinary(0,1);
    }
   /* else if (v[0]=="and"){
        for(int i=1;i<vecsize;i++){
           if (m.find(v[i])==m.end()){
                errorMessage+="ERROR: Register number "+v[i]+" is not valid";
                return;
           }
        }
        translated+=ConverttoBinary(1,3)+" "+m[v[1]]+" "+m[v[2]]+" "+ConverttoBinary(0,1);
    }
    else if (v[0]=="or"){
        for(int i=1;i<vecsize;i++){
           if (m.find(v[i])==m.end()){
                errorMessage+="ERROR: Register number "+v[i]+" is not valid";
                return;
           }
        }
        translated+=ConverttoBinary(1,3)+" "+m[v[1]]+" "+m[v[2]]+" "+ConverttoBinary(0,1);
    }
*/
}
